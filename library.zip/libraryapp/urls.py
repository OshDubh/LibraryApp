from django.contrib import admin
from django.urls import path
from .views import *

urlpatterns = [
 path('books/', view_all_books, name='all_books'),
 path('books/<int:bookid>/', view_single_book, name='single_book'),
 path('books/year/<int:year>/', view_books_by_year, name='book_by_year'),
 path('books/category/<str:cat>/', view_books_by_category, name='book_by_category')
]