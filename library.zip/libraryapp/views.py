from django.shortcuts import render, HttpResponse, get_object_or_404
from .models import Book


# a page to display all the books in the library
def view_all_books(request):
	all_books = Book.objects.all()
	return render(request, 'all_books.html', {'books':all_books} )

# the page to view when we want to see the details on just one book
def view_single_book(request, bookid):
	single_book = get_object_or_404(Book, id=bookid)
	return render(request, 'single_book.html', {'book':single_book})

# view a page of all the books by year
def view_books_by_year(request, year):
	# variables
	books = [] # a list where we add all the books that match

	# loop over the books and get the ones that match the year
	for book in Book.objects.all():
		if book.year == year:
			books.append(book)

	return render(request, 'all_books.html', {'books':books})

def view_books_by_category(request, cat):
	books_by_category = Book.objects.filter(category__icontains=cat,) # get a filtered list of the books
	return render(request, 'all_books.html', {'books':books_by_category})