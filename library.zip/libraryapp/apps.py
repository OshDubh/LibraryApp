from django.apps import AppConfig


class LibraryappConfig(AppConfig):
    name = 'libraryapp'
